<?php
session_start();

// Array de produtos (em um sistema real, viria do banco de dados)
$produtos = [
    [
        'id' => 1,
        'nome' => 'Shampoo Natural',
        'preco' => 29.90,
        'descricao' => 'Shampoo 100% natural e vegano',
        'imagem' => 'img/shampoo.jpg'
    ],
    [
        'id' => 2,
        'nome' => 'Sabonete Orgânico',
        'preco' => 15.90,
        'descricao' => 'Sabonete artesanal com ingredientes orgânicos',
        'imagem' => 'img/sabonete.jpg'
    ],
    [
        'id' => 3,
        'nome' => 'Óleo Essencial',
        'preco' => 45.00,
        'descricao' => 'Óleo essencial de lavanda 100% puro',
        'imagem' => 'img/oleo.jpg'
    ]
];

// Retorna os produtos em formato JSON se for uma requisição AJAX
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    header('Content-Type: application/json');
    echo json_encode($produtos);
    exit();
}
?>