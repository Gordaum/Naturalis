<?php
// Iniciar a sessão para acessar os dados do usuário
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario'])) {
    // Se a requisição for AJAX, retorna erro em JSON
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        http_response_code(401);
        echo json_encode(['erro' => 'Usuário não está logado']);
        exit();
    }
    // Se for acesso direto, redireciona para login
    header('Location: login.html');
    exit();
}

// Para demonstração, vamos simular alguns dados do usuário
// Em um sistema real, estes dados viriam do banco de dados
$usuario = [
    'nome' => $_SESSION['usuario'] ?? 'Usuário',
    'email' => $_SESSION['email'] ?? 'email@exemplo.com',
    'data_cadastro' => date('d/m/Y', strtotime($_SESSION['data_cadastro'] ?? '2025-09-15')),
    'ultimo_acesso' => date('d/m/Y H:i', strtotime($_SESSION['ultimo_acesso'] ?? date('Y-m-d H:i:s')))
];

// Retorna os dados em formato JSON
header('Content-Type: application/json');
echo json_encode($usuario);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil - Naturallis</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .profile-container {
            background-color: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            margin: 2rem auto;
        }

        .profile-header {
            text-align: center;
            margin-bottom: 2rem;
            position: relative;
        }

        .profile-picture {
            width: 120px;
            height: 120px;
            background-color: #6aa84f;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 3em;
        }

        .profile-info {
            background-color: #f4f8f4;
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }

        .info-group {
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dde5dd;
        }

        .info-group:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .info-label {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 0.3rem;
        }

        .info-value {
            color: #333;
            font-size: 1.1em;
            font-weight: 500;
        }

        .profile-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .profile-actions button {
            padding: 0.75rem;
        }

        .profile-actions button.secondary {
            background-color: #fff;
            border: 2px solid #6aa84f;
            color: #6aa84f;
        }

        .profile-actions button.secondary:hover {
            background-color: #f4f8f4;
        }

        .logout-button {
            position: absolute;
            top: 0;
            right: 0;
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9em;
        }

        .logout-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <div class="profile-header">
            <div class="profile-picture">
                <i class="fas fa-user"></i>
            </div>
            <h2>Meu Perfil</h2>
            <form action="logout.php" method="post" style="display: inline;">
                <button type="submit" class="logout-button">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </form>
        </div>

        <div class="profile-info">
            <div class="info-group">
                <div class="info-label">Nome</div>
                <div class="info-value"><?php echo htmlspecialchars($usuario['nome']); ?></div>
            </div>
            <div class="info-group">
                <div class="info-label">E-mail</div>
                <div class="info-value"><?php echo htmlspecialchars($usuario['email']); ?></div>
            </div>
            <div class="info-group">
                <div class="info-label">Data de Cadastro</div>
                <div class="info-value"><?php echo date('d/m/Y', strtotime($usuario['data_cadastro'])); ?></div>
            </div>
            <div class="info-group">
                <div class="info-label">Último Acesso</div>
                <div class="info-value"><?php echo date('d/m/Y H:i', strtotime($usuario['ultimo_acesso'])); ?></div>
            </div>
        </div>

        <div class="profile-actions">
            <button onclick="window.location.href='editar_perfil.php'" class="secondary">
                <i class="fas fa-edit"></i> Editar Perfil
            </button>
            <button onclick="window.location.href='index.php'">
                <i class="fas fa-home"></i> Voltar para Home
            </button>
        </div>
    </div>
</body>
</html>