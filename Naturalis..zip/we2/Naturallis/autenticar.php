<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    // Em um sistema real, você verificaria as credenciais no banco de dados
    // Este é apenas um exemplo para demonstração
    if ($email === 'teste@email.com' && $senha === '123456') {
        $_SESSION['usuario'] = 'Usuário Teste';
        $_SESSION['email'] = $email;
        $_SESSION['data_cadastro'] = '2025-09-15';
        $_SESSION['ultimo_acesso'] = date('Y-m-d H:i:s');
        
        header('Location: perfil.php');
        exit();
    } else {
        header('Location: login.html?erro=1');
        exit();
    }
}

header('Location: login.html');
exit();
?>